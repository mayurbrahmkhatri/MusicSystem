const express = require('express');
// const { checkSchema } = require('express-validator');
// const { savePlaylist } = require('./services');
const { getPlaylist } = require('./services');
const { getPlaylistById } = require('./services');
// const { updatePlaylist } = require('./services'); 
const { deletePlaylist } = require('./services');
const { addPlaylistValidation } = require('./validation');
const { optinalFunction } = require('./services');

const { searchPlaylist} = require('./services');


const router = express.Router();

// router.post('/', addPlaylistValidation, savePlaylist);
// router.post('/:playlist_id', updatePlaylist);
router.post('/:playlist_id?', addPlaylistValidation, optinalFunction);
router.get('/', getPlaylist);
router.get('/:playlist_id', getPlaylistById);
router.delete('/:playlist_id', deletePlaylist);
router.get('/search/:name', searchPlaylist);


module.exports = router;
