const express = require('express');
const { createUserFav, getAllUserFav, getUserFavById, removeUserFav } = require('./services');
// const { addUserFavValidationSchema } = require('./validation');

const router = express.Router();

router.post('/', createUserFav); 
router.get('/:id', getAllUserFav);
router.get('/:u_id/:s_id', getUserFavById);
router.delete('/:u_id/:s_id', removeUserFav);


module.exports = router;
