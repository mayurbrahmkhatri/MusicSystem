module.exports = (sequelize, Sequelize) => {
  const Songs = sequelize.define('songs', {
    songId: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    songName: {
      type: Sequelize.STRING,
    },
    movieName: {
      type: Sequelize.STRING,
    },
    artistName: {
      type: Sequelize.STRING,
    },
    path: {
      type: Sequelize.STRING,
    },
    genreId: {
      type: Sequelize.INTEGER,
    },
    is_active: {
      type: Sequelize.BOOLEAN,
    },
  });
  return Songs;
};
