const messages = require('./messages.json');


module.exports = key => (messages[key]);
