const { database: { host, user, password, databaseName,
  pool: { max, min, acquire, idle } } } = require('../../config');
const Sequelize = require('sequelize');

const sequelize = new Sequelize(databaseName, user, password, {
  host,
  dialect: 'postgres',
  pool: {
    max,
    min,
    acquire,
    idle,
  },
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.songs = require('./models/songs.model')(sequelize, Sequelize);
db.genre = require('./models/genre.model')(sequelize, Sequelize);
db.playlist = require('./models/playlist.models')(sequelize, Sequelize);
db.playlist_details = require('./models/playlist_details.models')(sequelize, Sequelize);
db.albums = require('./models/album.model')(sequelize, Sequelize);
db.album_details = require('./models/album_details.model')(sequelize, Sequelize);
db.users = require('./models/user.model')(sequelize, Sequelize);
db.user_fav = require('./models/user-fav.model')(sequelize, Sequelize);

module.exports = {
  db,
};
