/* eslint-disable no-unused-vars */
const { db: { albums } } = require('../');
const logger = require('../../../logger');
const Sequelize = require('sequelize');

const { Op } = Sequelize;


/**
 * Insert/Save Albums
 *
 * @param {*} data
 */
exports.saveAlbums = async (data) => {
  try {
    return albums.create(data).then(res => res).catch(err => err);
  } catch (error) {
    logger.log('Error in Save Albums ', error);
    throw error;
  }
};

// eslint-disable-next-line consistent-return
exports.updateAlbums = async (id, data) => {
  try {
    await albums.update(data, { where: { id } });
  } catch (error) {
    logger.log('Error in delete albums', error);
    return error;
  }
};

exports.getAlbumById = async (id) => {
  try {
    return albums.findOne({ where: { id } }).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in get album by id', error);
    return error;
  }
};
exports.getAlbums = async (page) => {
  try {
    const data = await albums.findAndCountAll({ raw: true, limit: 10, offset: page * 10 });


    return data;
  } catch (error) {
    logger.log('Error in get albums', error);
    return error;
  }
};

exports.deleteById = async (id) => {
  try {
    return await albums.destroy({ where: { id } });
  } catch (error) {
    logger.log('Error in delete albums', error);
    return error;
  }
};

exports.searchAlbum = async (term) => {
  try {
    const data = await albums.findAll({ where: { albumName: { [Op.iLike]: `%${term}%` } } });
    return data;
  } catch (error) {
    logger.log('Error in delete albums', error);
    return error;
  }
};

