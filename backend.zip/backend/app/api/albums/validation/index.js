
const { addAlbumNameValidation } = require('./albumValidation');

module.exports = {
  addAlbumNameValidation,
};
