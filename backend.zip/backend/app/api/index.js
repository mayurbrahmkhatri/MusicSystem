const songsRoute = require('./songs/route');
const genreRoute = require('./genre/route');
const playlistRoute = require('./playlist/route');
const playlistDetailsRoute = require('./playlist_detail/route');
const albumsRoute = require('./albums/route');
const albumDetailsRoute = require('./albumDetails/route');
const userRoute = require('./user/route');
const userFavRoute = require('./userFav/route');



module.exports = {
  songsRoute,
  genreRoute,
  playlistRoute,
  playlistDetailsRoute,
  albumsRoute,
  albumDetailsRoute,
  userRoute,
  userFavRoute,
};
