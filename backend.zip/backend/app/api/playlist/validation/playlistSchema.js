const joi = require('@hapi/joi');

const schema = {
    playlist: joi.object({
        playlist_name: joi.string().max(15).required(),
        user_id: joi.number().required()
    })
}

module.exports = schema;
