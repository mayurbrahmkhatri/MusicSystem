const { userFav: { removeUserFav } } = require('../../../commons/db/dao');


/**
 * 
 * @param {*} req 
 * @param {*} resp 
 * @param {*} next 
 */

module.exports = async(req, resp, next) => {
    const {u_id, s_id} = req.params;
    try {
        await removeUserFav(u_id, s_id);
        resp.status(200).send("Removed song from favourites");
    }
    catch (error) {
        console.log('Error in removing song from favourite ', error);
        next(error);
    }
};
