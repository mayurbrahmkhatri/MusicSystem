const { userFav: { getUserFavById } } = require('../../../commons/db/dao');

/**
 * 
 * @param {*} req 
 * @param {*} resp 
 * @param {*} next 
 */

 module.exports = async (req, resp, next) => {
    const {u_id, s_id} = req.params;
    try {
        const response = await getUserFavById(u_id, s_id);
        const answer = {
            data: response,
            msg: "User fav list",
            status_code: 200,
        };
        resp.status(200).send(answer);
    }
    catch (error) {
        console.log(error);
    }
};
