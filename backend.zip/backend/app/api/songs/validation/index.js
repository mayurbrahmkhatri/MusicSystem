const { addSongsValidation } = require('./songValidation');

module.exports = {
  addSongsValidation,
};
