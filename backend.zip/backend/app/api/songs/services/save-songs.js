const { songsDao: { saveSongs, updateSongs } } = require('../../../commons/db/dao');
const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async function optinalFunction(req, resp, next) {
  if (req.params.id) {
    const { id } = req.params;
    const { body: { songName, movieName, artistName, path, genreId } } = req;

    try {
      const data = {
        songName,
        movieName,
        artistName,
        path,
        genreId,
        is_active: 1,

      };

      await updateSongs(songId, data);
      const answer = {

        msg: messages('songsUpdatedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  } else {
    const { body: { songName, movieName, artistName, path, genreId } } = req;
    const data = {
      songName,
      movieName,
      artistName,
      path,
      genreId,
      is_active: 1,

    };
    try {
      const response = await saveSongs(data);
      const answer = {
        data: response,
        msg: messages('songSavedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  }
};
