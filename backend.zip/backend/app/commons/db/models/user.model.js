module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define('user', {
        userId: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        userName: {
            type: Sequelize.STRING,
            allowNull: false,
            unique: true,
        },
        firstName: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                len: [3,25],
            }
        },
        lastName: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                len: [3,25]
            }
        },
        email: {
            type: Sequelize.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true,
            }
        },
        password: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                min: 4,
            }
        },
        contactNum: {
            type: Sequelize.BIGINT,
            validate: {
                isInt: true,
            }
        },
        profilePic: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        isActive: {
            type: Sequelize.BOOLEAN,
            defaultValue: true,
        }, 
    });
    return User;
};
