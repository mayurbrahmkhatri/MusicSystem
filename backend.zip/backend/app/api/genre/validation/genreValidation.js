const { genre } = require("./genreSchema")

module.exports = {
  addGenreValidation : async (req,res,next) => {
    const value = await genre.validate(req.body);
    if(value.error){
      res.json({
        success: 0,
        message: value.error.details[0].message,
        status_code: 400,
      });
    }else{
      next();
    }
  }
};


// const { messages } = require('../../../commons/util');

// const validations = {
//   genreNameValidation: {
//     in: ['body'],
//     exists: {
//       options: {
//         checkNull: true,
//         checkFalsy: true,
//       },
//       errorMessage: messages('genreNameEmptyMessage'),
//     },
//   },

// };

// const saveGenreValidationSchema = {
//   genreName: validations.genreNameValidation,

// };

// module.exports = {
//   saveGenreValidationSchema,
// };

