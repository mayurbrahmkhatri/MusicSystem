const { addPlaylistDetailsValidation } = require('./playlistDetailsValidation');

module.exports = {
  addPlaylistDetailsValidation,
};
