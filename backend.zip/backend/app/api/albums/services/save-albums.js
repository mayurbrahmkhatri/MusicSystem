const { albumsDao: { saveAlbums, updateAlbums } } = require('../../../commons/db/dao');
const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async function optinalFunction(req, resp, next) {
  if (req.params.id) {
    const { id } = req.params;
    const { body: { albumName, genreId } } = req;

    try {
      const data = {
        albumName,
        genreId,
        isActive: 1,


      };

      await updateAlbums(id, data);
      const answer = {

        msg: messages('albumUpdated'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  } else {
    const { body: { albumName, genreId } } = req;
    const data = {
      albumName,
      genreId,
      isActive: 1,


    };
    try {
      const response = await saveAlbums(data);
      const answer = {
        data: response,
        msg: messages('AlbumSavedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  }
};
