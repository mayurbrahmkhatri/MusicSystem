const { response } = require('express');
const { db: { playlist_details } } = require('..');
const logger = require('../../../logger');

/**
 * Insert/Save playlist
 *
 * @param {*} data
 */
exports.savePlaylistDetails = async (data) => {
  try {
    return await playlist_details.create(data)
  } catch (error) {
    console.log('Error in Save playlist_deatils ', error);
    return error;
  }
};

exports.getPlaylistDetails = async()=>{
  try{
    return await playlist_details.findAll({ raw:true });
     }catch(error)
     {
       logger.log('Error in get playlist details',error);
       return error;
     }
};

exports.getPlaylistDetailsById = async(id)=>{
  try{
    return await playlist_details.findAll({ 
      where: { id },
      raw:true });
     }catch(error)
     {
       logger.log('Error in get playlist details',error);
       return error;
     }
};

exports.updatePlaylistDetails = async (id, data) => {
    try {
      return await playlist_details.update(data, {
        where: { id },
      })
    } catch (error) {
      console.log('Error in Update playlist ', error);
      throw error;
    }
  };
  
  exports.deletePlaylistDetailsById = async(id) => {
    try {
      return await playlist_details.destroy( {
        where:{ id  },
      });
    } catch (error){
      console.log('Error in delete playlist',error);
      return error;
    }
  }
  
