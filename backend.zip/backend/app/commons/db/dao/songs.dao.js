const { db: { songs } } = require('../');
const logger = require('../../../logger');
const Sequelize = require('sequelize');

const { Op } = Sequelize;

/**
 * Insert/Save Songs
 *
 * @param {*} data
 */
exports.saveSongs = async (data) => {
  try {
    return songs.create(data).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in Save Songs ', error);
    throw error;
  }
};

exports.updateSongs = async (id, data) => {
  try {
    return songs.update(data, {
      where: { id },
    }).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in Update Songs ', error);
    throw error;
  }
};

exports.getSongs = async (page) => {
  try {
    const data = await songs.findAndCountAll({ raw: true, limit: 2, offset: page * 2 });

    return data;
  } catch (error) {
    console.log('Error in get songs', error);
    return error;
  }
};


exports.getSongsById = async (songId) => {
  try {
    return await songs.findAll({
      where: { songId },
      raw: true });
  } catch (error) {
    logger.log('Error in get playlist', error);
    return error;
  }
};

exports.deleteSongsById = async (songId) => {
  try {
    return await songs.destroy({
      where: { songId },
    });
  } catch (error) {
    console.log('Error in delete songs', error);
    return error;
  }
};
exports.searchSongs = async (term) => {
  try {
    const data = await songs.findAll({ where: { songName: { [Op.iLike]: `%${term}%` } } });
    // console.log("data searched"+data);
    return data;
  } catch (error) {
    console.log('Error in search song', error);
    return error;
  }
};

