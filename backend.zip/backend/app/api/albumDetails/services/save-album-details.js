const { albumDetailsDao: { saveAlbumDetails, updateAlbumDetails } } = require('../../../commons/db/dao');
const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async function optinalFunction(req, resp, next) {
  if (req.params.id) {
    const { id } = req.params;
    const { body: { albumId, songId } } = req;

    try {
      const data = {
        albumId,
        songId,
        isActive: 1,


      };

      await updateAlbumDetails(id, data);
      const answer = {

        msg: messages('albumDetailssUpdated'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  } else {
    const { body: { albumId, songId } } = req;
    const data = {
      albumId,
      songId,
      isActive: 1,


    };
    try {
      const response = await saveAlbumDetails(data);
      const answer = {
        data: response,
        msg: messages('albumDetailSavedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Songs Service ', error);
      next(error);
    }
  }
};
