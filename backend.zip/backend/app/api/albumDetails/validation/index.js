const { addAlbumDetailsValidation } = require('./albumDetailsValidation');

module.exports = {
  addAlbumDetailsValidation,
};
