const { addUserFavValidationSchema } = require('./userFavValidation');

module.exports = {
    addUserFavValidationSchema,
};

