const joi = require('@hapi/joi');

const schema = {
    userFav: joi.object({
        userId: joi.number().required(),
        songId: joi.number().required()
    })
}

module.exports = schema;
