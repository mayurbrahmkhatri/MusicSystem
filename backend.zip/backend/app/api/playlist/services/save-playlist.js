const { playlistDao: { savePlaylist, updatePlaylist } } = require('../../../commons/db/dao');
const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async function optinalFunction(req, resp, next) {
  if (req.params.id) {
    const { id } = req.params;
    const { body: { playlist_name, user_id } } = req;

    try {
      const data = {
        playlist_name,
        user_id,
        is_private: 1,
      };

      await updatePlaylist(id, data);
      const answer = {

        msg: messages('playlistUpdatedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save playlist Service ', error);
      next(error);
    }
  } else {
    const { body: { playlist_name, user_id } } = req;
    const data = {
      playlist_name,
      user_id,
      isActive: 1,
    };
    try {
      const response = await savePlaylist(data);
      const answer = {
        data: response,
        msg: messages('PlaylistSavedMessage'),
        status_code: 200,
      };
      resp.status(200).send(answer);
    } catch (error) {
      logger.log('Error in Save Playlist Service ', error);
      next(error);
    }
  }
};




// const { playlistDao: { savePlaylist } } = require('../../../commons/db/dao');
// const logger = require('../../../logger');
// const { messages } = require('../../../commons/util');
// /**
//  *
//  * @param {*} req
//  * @param {*} resp
//  * @param {*} next
//  */
// module.exports = async (req, resp, next) => {
//   const { body: { playlist_name,user_id } } = req;
//   const data = {
//     playlist_name,
//     user_id,
//     is_private : 1,
//   };
//   try {
//     await savePlaylist(data);
//     const answer = {
//       msg: messages('playlistSavedMessage'),
//       status_code: 200,
//     };

//     resp.status(200).send(answer);
//   } catch (error) {
//     logger.log('Error in Save playlist Service ', error);
//     next(error);
//   }
// };
