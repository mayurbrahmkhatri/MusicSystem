// Router declarations

const {
  songsRoute,
  genreRoute,
  playlistRoute,
  playlistDetailsRoute,
  albumsRoute, 
  albumDetailsRoute,
  userRoute, 
  userFavRoute, 

} = require('./api');


/**
 * initialize routes
 *
 * @param  {Object} server
 */
module.exports = (server) => {
  server.use('/songs', songsRoute);
  server.use('/genre', genreRoute );
  server.use('/playlist', playlistRoute);
  server.use('/playlist_details', playlistDetailsRoute);
  server.use('/albums', albumsRoute);
  server.use('/albumdetails', albumDetailsRoute);
  server.use('/user', userRoute);
  server.use('/fav', userFavRoute);


};
