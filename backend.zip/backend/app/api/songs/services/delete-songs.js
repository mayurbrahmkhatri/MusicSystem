const { songsDao: { deleteSongsById } } = require('../../../commons/db/dao');
// const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async (req, resp, next) => {
  const { params: { songId } } = req;
  try {
    await deleteSongsById(songId);
    resp.status(200).send(messages('deleteSongsById'));
  } catch (error) {
    console.log('Error in delete songs Service ', error);
    next(error);
  }
};
