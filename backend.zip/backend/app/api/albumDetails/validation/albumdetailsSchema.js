const joi = require('@hapi/joi');

const schema = {
  albumDetails: joi.object({
    albumId: joi.number().min(1).required(),
    songId: joi.number().min(1).required(),
  }),
};

module.exports = schema;
