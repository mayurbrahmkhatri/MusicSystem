const { songs } = require("./songSchema")

module.exports = {
  addSongsValidation : async (req,res,next) => {
    const value = await songs.validate(req.body);
    if(value.error){
      res.json({
        success: 0,
        message: value.error.details[0].message,
        status_code: 400,
      });
    }else{
      next();
    }
  }
};

// const { messages } = require('../../../commons/util');

// const validations = {
//   songNameValidation: {
//     in: ['body'],
//     exists: {
//       options: {
//         checkNull: true,
//         checkFalsy: true,
//       },
//       errorMessage: messages('songNameEmptyMessage'),
//     },
//   },
//   movieNameValidation: {
//     in: ['body'],
//     exists: {
//       options: {
//         checkNull: true,
//         checkFalsy: true,
//       },
//       errorMessage: messages('movieNameEmptyMessage'),
//     },
//   },
//   artistNameValidation: {
//     in: ['body'],
//     exists: {
//       options: {
//         checkNull: true,
//         checkFalsy: true,
//       },
//       errorMessage: messages('artistNameEmptyMessage'),
//     },
//   },
//   pathValidation: {
//     in: ['body'],
//     exists: {
//       options: {
//         checkNull: true,
//         checkFalsy: true,
//       },
//       errorMessage: messages('pathEmptyMessage'),
//     },
//   },

// };

// const saveSongsValidationSchema = {
//   songName: validations.songNameValidation,
//   movieName: validations.movieNameValidation,
//   artistName: validations.artistNameValidation,
//   path: validations.pathValidation,

// };

// module.exports = {
//   saveSongsValidationSchema,
// };

