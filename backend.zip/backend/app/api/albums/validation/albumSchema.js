const joi = require('@hapi/joi');

const schema = {
  album: joi.object({
    albumName: joi.string().max(15).required(),
    genreId: joi.any(),
  }),
};

module.exports = schema;
