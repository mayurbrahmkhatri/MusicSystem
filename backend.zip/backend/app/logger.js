const config = require('./config');
const { name } = require('../package');
const logger = require('./commons/util/logger');

module.exports = logger(name, config);
