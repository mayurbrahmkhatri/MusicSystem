module.exports = (sequelize, Sequelize) => {
    const playlist = sequelize.define('playlist', {
      playlist_id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      playlist_name: {
        type: Sequelize.STRING,
      },
      user_id: {
        type: Sequelize.INTEGER,
        foreignKey: true,
      },
      is_private: {
        type: Sequelize.STRING,
      },
    });
  
    return playlist;
  };
