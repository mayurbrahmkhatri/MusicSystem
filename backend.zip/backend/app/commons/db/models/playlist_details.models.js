module.exports = (sequelize, Sequelize) => {
    const playlist_details = sequelize.define('playlist_details', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      playlist_id: {
        type: Sequelize.INTEGER,
        foreignKey: true,
      },
      song_id: {
        type: Sequelize.INTEGER,
        foreignKey: true,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
      },
    });
  
    return playlist_details;
  };
