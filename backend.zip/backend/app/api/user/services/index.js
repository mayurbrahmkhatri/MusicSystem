const createUser = require('./create-user');
const getUserById = require('./get-user-by-id');
const getUsers = require('./get-users');
const deleteUser = require('./delete-user');
const updateUser = require('./update-user');

module.exports = {
    createUser, getUsers, getUserById, deleteUser, updateUser,
};
