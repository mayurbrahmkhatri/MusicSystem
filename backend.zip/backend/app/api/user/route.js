const express = require('express');
const { checkSchema } = require('express-validator');
const { createUser } = require('./services');
const { getUsers } = require('./services');
const { getUserById } = require('./services');
const { deleteUser } = require('./services');
const { updateUser } = require('./services');
const { createUserValidationSchema } = require('./validation');

const router = express.Router();

// route for creating user
router.post('/', checkSchema(createUserValidationSchema), createUser); 
router.get('/', getUsers);
router.get('/:id', getUserById);
router.post('/:userId', updateUser);
router.delete('/:userId', deleteUser);

module.exports = router;
