module.exports = (sequelize, Sequelize) => {
    const Albums = sequelize.define('albums', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      albumName: {
        type: Sequelize.STRING,
      },
      genreId: {
        type: Sequelize.INTEGER,
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        default: true,
      },
    });
  
    return Albums;
  };
  