const { createUserValidationSchema } = require('./create-user-validation');

module.exports = {
    createUserValidationSchema,
}
