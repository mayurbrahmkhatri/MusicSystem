/* eslint-disable camelcase */
const { db: { album_details } } = require('../');
const logger = require('../../../logger');

/**
 * Insert/Save Albums_album_details
 *
 * @param {*} data
 */
exports.saveAlbumDetails = async (data) => {
  try {
    return album_details.create(data).then(res => res).catch(err => err);
  } catch (error) {
    logger.log('Error in Save Albums_album_details ', error);
    throw error;
  }
};

// eslint-disable-next-line consistent-return
exports.updateAlbumDetails = async (id, data) => {
  try {
    await album_details.update(data, { where: { id } });
  } catch (error) {
    logger.log('Error in delete album_details', error);
    return error;
  }
};

exports.getAlbumDetailsById = async (id) => {
  try {
    return album_details.findOne({ where: { id } }).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in get album by id', error);
    return error;
  }
};
exports.getAlbumDetails = async () => {
  try {
    return await album_details.findAll({ raw: true });
  } catch (error) {
    logger.log('Error in get album_details', error);
    return error;
  }
};

exports.deleteAlbumDetailsById = async (id) => {
  try {
    return await album_details.destroy({ where: { id } });
  } catch (error) {
    logger.log('Error in delete album_details', error);
    return error;
  }
};
