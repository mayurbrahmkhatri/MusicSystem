const { playlistDao: { deletePlaylistById } } = require('../../../commons/db/dao');
// const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async (req, resp, next) => {
  const {params : {playlist_id}} = req;
  try {
    await deletePlaylistById(playlist_id);
    resp.status(200).send(messages('deletePlaylistById'));
  } catch (error) {
    console.log('Error in delete playlist Service ', error);
    next(error);
  }
};
