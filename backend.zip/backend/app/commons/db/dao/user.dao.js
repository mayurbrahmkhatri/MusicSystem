const { db: { users } } = require('../');

/**
 * 
 * @param { * } data
 */

exports.createUser = async (data) => {
    try {
        return await users.create(data).then(response => response).catch(err => err);
    }
    catch (error) {
        console.log('Error in creating user', error);
        throw error;
    }
};

exports.getUsers = async () => {
    try {
        return await users.findAll({ raw : true });
    }
    catch (error) {
        console.log('Error while getting all users', error);
        return error;
    }
};

exports.getUserById = async (userId) => {
    try {
        return await users.findAll({
            where : { userId },
            raw: true}).then(response => response).catch(err => err);
    }
    catch (error) {
        console.log("Error while getting user with id", error);
        return error;
    }

};

exports.updateUser = async (userId, data) => {
    try {
        return await users.update(data, {
            where: {userId},
        });
    }
    catch (error) {
        console.log('Error while updateing user information', error);
        throw error;
    }
};

exports.deleteUser = async (userId) => {
    try {
        return await users.destroy({
            where : {userId}
        });
    }
    catch (error) {
        console.log('Error while deleting user', error);
        throw error;
    }
};
