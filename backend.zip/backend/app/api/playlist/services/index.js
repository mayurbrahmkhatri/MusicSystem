// const savePlaylist = require('./save-playlist');
const getPlaylist = require('./get-playlist');
const getPlaylistById = require('./get-playlist-by-id');
// const updatePlaylist = require('./update-playlist');
const deletePlaylist = require('./delete-playlist-by-id');
const optinalFunction = require('./save-playlist');
const searchPlaylist = require('./search-by-name');


module.exports = {
  // savePlaylist,
  getPlaylist,
  getPlaylistById,
  // updatePlaylist,
  deletePlaylist,
  searchPlaylist,
  optinalFunction,
};
