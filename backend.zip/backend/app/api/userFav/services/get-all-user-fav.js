const { userFav: { getAllUserFav } } = require('../../../commons/db/dao');

/**
 * 
 * @param {*} req 
 * @param {*} resp 
 * @param {*} next 
 */

 module.exports = async (req, resp, next) => {
    const {id} = req.params;
    try {
        const response = await getAllUserFav(id);
        const answer = {
            data: response,
            msg: "User fav list",
            status_code: 200,
        };
        resp.status(200).send(answer);
    }
    catch (error) {
        console.log(error);
    }
};
