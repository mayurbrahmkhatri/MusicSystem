const joi = require('@hapi/joi');

const schema = {
    songs: joi.object({
        songName: joi.string().max(15).required(),
        movieName: joi.string().max(15).required(),
        artistName: joi.string().max(15).required(),
        path: joi.string().max(50).required(),
        genreId: joi.number().required()
    })
}

module.exports = schema;