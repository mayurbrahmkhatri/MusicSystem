module.exports = (sequlize, Sequelize) => {
    const userFav = sequlize.define('user', {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        userId: {
            type: Sequelize.INTEGER,
            foreignKey: true,
        },
        songId: {
            type: Sequelize.INTEGER,
            foreignKey: true,
        },
        isActive: {
            type: Sequelize.BOOLEAN,
            defaultValue: true,
        },
    });
    return userFav;
};
