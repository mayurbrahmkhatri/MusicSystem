const songsDao = require('./songs.dao');
const genreDao = require('./genre.dao');
const playlistDao = require('./playlist.dao');
const playlistDetailsDao = require('./playlist_details.dao')
const albumsDao = require('./albums.dao');
const albumDetailsDao = require('./album_details.dao');
const userDao = require('./user.dao');
const userFav = require('./user-fav.dao');



module.exports = {
  songsDao,
  genreDao,
  playlistDao,
  playlistDetailsDao,
  albumsDao, 
  albumDetailsDao,
  userDao,
  userFav,
};
