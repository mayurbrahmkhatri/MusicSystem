const {  addGenreValidation  } = require('./genreValidation');

module.exports = {
    addGenreValidation ,
};
