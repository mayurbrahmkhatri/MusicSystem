module.exports = (sequelize, Sequelize) => {
    const albumsDetails = sequelize.define('album_details', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      albumId: {
        type: Sequelize.INTEGER,
      },
      songId: {
        type: Sequelize.INTEGER,
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        default: true,
      },
    });
  
    return albumsDetails;
  };
  