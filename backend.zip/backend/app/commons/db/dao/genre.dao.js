const { db: { genre } } = require('../');
const logger = require('../../../logger');

/**
 * Insert/Save Genre
 *
 * @param {*} data
 */
exports.saveGenre = async (data) => {
  try {
    return genre.create(data).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in Save Genre ', error);
    throw error;
  }
};

exports.updateGenre = async (genreId, data) => {
  try {
    return genre.update(data, {
      where: { genreId },
    }).then(response => response).catch(err => err);
  } catch (error) {
    logger.log('Error in Update Genre ', error);
    throw error;
  }
};

exports.getGenre = async () => {
  try {
    return await genre.findAll({ raw: true });
  } catch (error) {
    logger.log('Error in get Genre', error);
    return error;
  }
};

exports.getGenreById = async (genreId) => {
  try {
    return await genre.findAll({
      where: { genreId },
      raw: true });
  } catch (error) {
    logger.log('Error in get Genre', error);
    return error;
  }
};

exports.deleteGenreById = async (genreId) => {
  try {
    return await genre.destroy({
      where: { genreId },
    });
  } catch (error) {
    console.log('Error in delete genre', error);
    return error;
  }
};
