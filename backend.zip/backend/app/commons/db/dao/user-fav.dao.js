const { db: {user_fav} } = require('../');

/**
 * 
 * @param { * } data
 */

 exports.createUserFav = async (data) => {
    try {
        return await user_fav.create(data).then(response => response).catch(err => err);
    }
    catch (error) {
        console.log('Error in creating favourite', error);
        throw error;
    }
};


exports.getAllUserFav = async (userId) => {
    try {
        return await user_fav.findAll({
            where: {userId},
            raw : true,
        });
    }
    catch (error) {
        console.log('Error while getting user favourite list', error);
        return error;
    }
};

exports.getUserFavById = async (userId, songId) => {
    try {
        return await user_fav.findAll({
            where: {userId, songId},
            raw: true,
        });
    }
    catch (error) {
        console.log('Error while getting user favourite song', error);
        return error;
    }
};

exports.removeUserFav = async (userId, songId) => {
    try {
        return await user_fav.destroy({
            where: {userId, songId},
        });
    }
    catch (error) {
        console.log('Error while removing song from favourits', error);
        return error;
    }
};
