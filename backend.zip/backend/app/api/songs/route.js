const express = require('express');
// const { checkSchema } = require('express-validator');
const {  addSongsValidation } = require('./validation');
const { getSongs } = require('./services');
const { getSongsById } = require('./services');
const { optinalFunction } = require('./services');
const { deleteSongs } = require('./services');
const { searchSongs } = require('./services');


const router = express.Router();

router.get('/', getSongs);
router.get('/:songId', getSongsById);
router.post('/:songId?', addSongsValidation, optinalFunction);
router.delete('/:songId', deleteSongs);
router.get('/search/:name', searchSongs);

module.exports = router;
