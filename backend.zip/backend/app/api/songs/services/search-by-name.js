const { songsDao: { searchSongs } } = require('../../../commons/db/dao');
const logger = require('../../../logger');
const { messages } = require('../../../commons/util');
/**
 *
 * @param {*} req
 * @param {*} resp
 * @param {*} next
 */
module.exports = async (req, resp, next) => {
  try {
    const term = req.params.name;
    console.log(term);
    const data = await searchSongs(term);
    console.log(data);

    const ans = {
      data,
      msg: messages('searchSongs'),
      status_code: 200,
    };
    resp.status(200).send(ans);
  } catch (error) {
    console.log('Error in Search Songs Service ', error);
    next(error);
  }
};
