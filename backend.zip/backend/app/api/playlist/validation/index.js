const { addPlaylistValidation } = require('./playlistValidation');

module.exports = {
  addPlaylistValidation,
};
