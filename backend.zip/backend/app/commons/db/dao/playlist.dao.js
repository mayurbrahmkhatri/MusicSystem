const { response } = require('express');
const { db: { playlist } } = require('../');
const logger = require('../../../logger');
const Sequelize = require('sequelize');
const { Op } = Sequelize;


/**
 * Insert/Save playlist
 *
 * @param {*} data
 */
exports.savePlaylist = async (data) => {
  try {
    return await playlist.create(data)
  } catch (error) {
    logger.log('Error in Save playlist ', error);
    return error;
  }
};

exports.getPlaylist = async (page) => {
  try {
    const data = await playlist.findAndCountAll({ raw: true, limit: 2, offset: page * 2 });
    return data;
  } catch (error) {
    logger.log('Error in get playlist', error);
    return error;
  }
};

exports.getPlaylistById = async(playlist_id)=>{
  try{
    return await playlist.findAll({ 
      where: { playlist_id },
      raw:true });
     }catch(error)
     {
       logger.log('Error in get playlist',error);
       return error;
     }
};

exports.updatePlaylist = async (playlist_id, data) => {
  try {
    return await playlist.update(data, {
      where: { playlist_id },
    })
  } catch (error) {
    logger.log('Error in Update playlist ', error);
    throw error;
  }
};

exports.deletePlaylistById = async(playlist_id) => {
  try {
    return await playlist.destroy( {
      where:{playlist_id  },
    });
  } catch (error){
    console.log('Error in delete playlist',error);
    return error;
  }
}

exports.searchPlaylist = async (term) => {
  try {
    const data = await playlist.findAll({ where: { playlist_name: { [Op.iLike]: `%${term}%` } } });
    return data;
  } catch (error) {
    logger.log('Error in delete playlist', error);
    return error;
  }
};
